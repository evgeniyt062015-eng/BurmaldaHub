package ru.belkajay.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;
import ru.belkajay.visual.module.Feature;
import ru.belkajay.visual.module.ModuleManager;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Per-tick cosmetic effects. Everything here is client-side only. */
public class Effects {
    public static double zoomCurrent = 1.0;
    public static double speed = 0.0;

    private static boolean wasOnGround = true;
    private static boolean addedNightVision = false;
    private static Vec3d lastPos = null;
    private static boolean lastAttackDown = false;
    private static final ArrayDeque<Long> clicks = new ArrayDeque<>();
    private static final List<double[]> rings = new ArrayList<>(); // x, y, z, age

    public static ParticleEffect particle(Feature f) {
        return switch (f.getMode()) {
            case "Heart" -> ParticleTypes.HEART;
            case "Flame" -> ParticleTypes.FLAME;
            case "Snow" -> ParticleTypes.SNOWFLAKE;
            case "Spark" -> ParticleTypes.ELECTRIC_SPARK;
            case "Cloud" -> ParticleTypes.CLOUD;
            case "Star" -> ParticleTypes.END_ROD;
            case "Happy" -> ParticleTypes.HAPPY_VILLAGER;
            default -> ParticleTypes.CRIT;
        };
    }

    public static int cps() {
        long now = System.currentTimeMillis();
        while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000) clicks.pollFirst();
        return clicks.size();
    }

    public static double zoomTarget() {
        return switch (ModuleManager.ZOOM.getMode()) {
            case "x3" -> 1.0 / 3.0;
            case "x4" -> 0.25;
            case "x6" -> 1.0 / 6.0;
            default -> 0.5;
        };
    }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) {
            addedNightVision = false;
            lastPos = null;
            rings.clear();
            zoomCurrent = 1.0;
            return;
        }

        // speed (blocks per second)
        Vec3d pos = p.getPos();
        if (lastPos != null) speed = Math.hypot(pos.x - lastPos.x, pos.z - lastPos.z) * 20.0;
        lastPos = pos;

        // CPS
        boolean attackDown = mc.options.attackKey.isPressed();
        if (attackDown && !lastAttackDown) clicks.addLast(System.currentTimeMillis());
        lastAttackDown = attackDown;

        // zoom (smooth)
        boolean zooming = ModuleManager.ZOOM.isEnabled() && BelkaJayClient.zoomKey != null
                && BelkaJayClient.zoomKey.isPressed() && mc.currentScreen == null;
        double target = zooming ? zoomTarget() : 1.0;
        zoomCurrent += (target - zoomCurrent) * 0.35;
        if (Math.abs(zoomCurrent - target) < 0.002) zoomCurrent = target;

        // jump circle
        boolean onGround = p.isOnGround();
        if (ModuleManager.JUMP_CIRCLE.isEnabled() && wasOnGround && !onGround && p.getVelocity().y > 0.2) {
            rings.add(new double[]{p.getX(), p.getY() + 0.05, p.getZ(), 0});
        }
        wasOnGround = onGround;
        ParticleEffect ringParticle = particle(ModuleManager.JUMP_CIRCLE);
        Iterator<double[]> it = rings.iterator();
        while (it.hasNext()) {
            double[] r = it.next();
            double radius = 0.35 + r[3] * 0.22;
            int n = (int) (12 + r[3] * 3);
            for (int i = 0; i < n; i++) {
                double a = (Math.PI * 2 * i) / n;
                mc.world.addParticle(ringParticle, r[0] + Math.cos(a) * radius, r[1], r[2] + Math.sin(a) * radius, 0, 0.01, 0);
            }
            r[3] += 1;
            if (r[3] > 6) it.remove();
        }

        // trail
        if (ModuleManager.TRAIL.isEnabled() && speed > 1.0 && !mc.options.getPerspective().isFirstPerson()) {
            mc.world.addParticle(particle(ModuleManager.TRAIL), p.getX(), p.getY() + 0.1, p.getZ(), 0, 0.02, 0);
        } else if (ModuleManager.TRAIL.isEnabled() && speed > 1.0) {
            mc.world.addParticle(particle(ModuleManager.TRAIL), p.getX(), p.getY() + 0.05, p.getZ(), 0, 0.02, 0);
        }

        // target ESP: particle ring that rotates around the entity under the crosshair
        if (ModuleManager.TARGET_ESP.isEnabled()) {
            Entity t = mc.targetedEntity;
            if (t instanceof LivingEntity le && le.isAlive()) {
                double time = (mc.world.getTime() % 40) / 40.0;
                double y = le.getY() + (Math.sin(time * Math.PI * 2) * 0.5 + 0.5) * le.getHeight();
                double radius = Math.max(0.5, le.getWidth() * 0.9);
                ParticleEffect pe = particle(ModuleManager.TARGET_ESP);
                for (int k = 0; k < 2; k++) {
                    double a = time * Math.PI * 4 + k * Math.PI;
                    mc.world.addParticle(pe, le.getX() + Math.cos(a) * radius, y, le.getZ() + Math.sin(a) * radius, 0, 0, 0);
                }
            }
        }

        // time changer (client-side only)
        if (ModuleManager.TIME_CHANGER.isEnabled()) {
            long t = switch (ModuleManager.TIME_CHANGER.getMode()) {
                case "Noon" -> 6000L;
                case "Sunset" -> 12500L;
                case "Night" -> 14500L;
                case "Midnight" -> 18000L;
                default -> 1000L;
            };
            mc.world.getLevelProperties().setTimeOfDay(t);
        }

        // fullbright via client-side night vision
        if (ModuleManager.FULLBRIGHT.isEnabled()) {
            StatusEffectInstance cur = p.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (cur == null || (addedNightVision && cur.getDuration() < 300)) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1200, 0, true, false, false));
                addedNightVision = true;
            }
        } else if (addedNightVision) {
            p.removeStatusEffect(StatusEffects.NIGHT_VISION);
            addedNightVision = false;
        }
    }
}

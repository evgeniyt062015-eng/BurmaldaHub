package ru.belkajay.visual;

import ru.belkajay.visual.module.ModuleManager;

public class Theme {
    // {primary, secondary}
    private static final int[][] COLORS = {
            {0xFFF4F3FA, 0xFFA9A8B8}, // Mono (from the avatar)
            {0xFF9ED8FF, 0xFF5C9FD6}, // Ice
            {0xFFC9A7FF, 0xFF8A63D2}, // Violet
            {0xFFA6F5D0, 0xFF5CBF98}, // Mint
            {0xFFFFB3C7, 0xFFD6728F}  // Rose
    };

    public static int primary() {
        return COLORS[ModuleManager.THEME.getModeIndex() % COLORS.length][0];
    }

    public static int secondary() {
        return COLORS[ModuleManager.THEME.getModeIndex() % COLORS.length][1];
    }
}

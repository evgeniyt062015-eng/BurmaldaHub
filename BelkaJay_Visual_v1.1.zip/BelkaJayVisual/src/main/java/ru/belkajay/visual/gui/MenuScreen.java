package ru.belkajay.visual.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import ru.belkajay.visual.Theme;
import ru.belkajay.visual.module.Feature;
import ru.belkajay.visual.module.ModuleManager;

public class MenuScreen extends Screen {
    private static final int MAIN_W = 130, CYCLE_W = 20, H = 20, GAP = 4, COL_GAP = 10;
    private int top;

    public MenuScreen() {
        super(Text.literal("Belka Jay"));
    }

    @Override
    protected void init() {
        int n = ModuleManager.ALL.size();
        int rows = (n + 1) / 2;
        int cellW = MAIN_W + 2 + CYCLE_W;
        int totalW = cellW * 2 + COL_GAP;
        int x0 = this.width / 2 - totalW / 2;
        top = this.height / 2 - (rows * (H + GAP)) / 2 + 6;

        for (int i = 0; i < n; i++) {
            Feature f = ModuleManager.ALL.get(i);
            int col = i / rows;
            int row = i % rows;
            int x = x0 + col * (cellW + COL_GAP);
            int y = top + row * (H + GAP);

            ButtonWidget main = ButtonWidget.builder(label(f), b -> {
                if (f.isModeOnly()) f.cycleMode(); else f.toggle();
                b.setMessage(label(f));
            }).dimensions(x, y, f.hasModes() && !f.isModeOnly() ? MAIN_W : cellW, H).build();
            this.addDrawableChild(main);

            if (f.hasModes() && !f.isModeOnly()) {
                this.addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> {
                    f.cycleMode();
                    main.setMessage(label(f));
                }).dimensions(x + MAIN_W + 2, y, CYCLE_W, H).build());
            }
        }
    }

    private static Text label(Feature f) {
        if (f.isModeOnly()) {
            return Text.literal(f.getName() + ": " + f.getMode());
        }
        String t = (f.isEnabled() ? "● " : "○ ") + f.getName()
                + (f.hasModes() ? " [" + f.getMode() + "]" : "");
        return Text.literal(t).formatted(f.isEnabled() ? Formatting.WHITE : Formatting.GRAY);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, "Belka Jay Visual", this.width / 2, top - 14, Theme.primary());
    }

    @Override
    public void removed() {
        ModuleManager.save();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}

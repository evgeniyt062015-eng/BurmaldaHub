package ru.belkajay.visual;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;
import ru.belkajay.visual.gui.MenuScreen;
import ru.belkajay.visual.module.ModuleManager;

public class BelkaJayClient implements ClientModInitializer {
    public static KeyBinding menuKey;
    public static KeyBinding zoomKey;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.belkajay.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.belkajay"));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.belkajay.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "category.belkajay"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                client.setScreen(new MenuScreen());
            }
            Effects.tick(client);
        });

        HudRenderCallback.EVENT.register(Hud::render);

        // Hit particles: purely cosmetic, spawned only on your own client
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient && ModuleManager.HIT_PARTICLES.isEnabled() && entity instanceof LivingEntity) {
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc.world != null) {
                    var effect = Effects.particle(ModuleManager.HIT_PARTICLES);
                    for (int i = 0; i < 14; i++) {
                        double dx = (mc.world.random.nextDouble() - 0.5) * 0.6;
                        double dy = mc.world.random.nextDouble() * 0.5;
                        double dz = (mc.world.random.nextDouble() - 0.5) * 0.6;
                        mc.world.addParticle(effect,
                                entity.getX(), entity.getY() + entity.getHeight() * 0.6, entity.getZ(),
                                dx, dy, dz);
                    }
                }
            }
            return ActionResult.PASS;
        });
    }
}

package ru.belkajay.visual.mixin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.belkajay.visual.module.ModuleManager;

@Mixin(InGameHud.class)
public abstract class InGameHudMixin {

    // hide the vanilla crosshair when the custom one is on
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void belkajay$crosshair(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        if (ModuleManager.CROSSHAIR.isEnabled()) {
            ci.cancel();
        }
    }
}

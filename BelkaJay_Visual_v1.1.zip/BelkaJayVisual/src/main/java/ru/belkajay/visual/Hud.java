package ru.belkajay.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import ru.belkajay.visual.module.Feature;
import ru.belkajay.visual.module.ModuleManager;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Hud {
    static final int BG = 0xB0050508;

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        if (mc.currentScreen != null && !(mc.currentScreen instanceof ChatScreen)) return;
        TextRenderer tr = mc.textRenderer;

        if (ModuleManager.WATERMARK.isEnabled()) watermark(ctx, tr);
        if (ModuleManager.POTION_HUD.isEnabled()) potions(ctx, mc, tr);
        if (ModuleManager.INFO.isEnabled()) info(ctx, mc, tr);
        if (ModuleManager.ARRAY_LIST.isEnabled()) arrayList(ctx, tr);
        if (ModuleManager.TARGET_HUD.isEnabled()) targetHud(ctx, mc, tr);
        if (ModuleManager.KEYSTROKES.isEnabled()) keystrokes(ctx, mc, tr);
        if (ModuleManager.ARMOR_HUD.isEnabled() || ModuleManager.TOTEMS.isEnabled()) items(ctx, mc, tr);
        if (ModuleManager.CROSSHAIR.isEnabled()) crosshair(ctx);
    }

    private static void box(DrawContext ctx, int x, int y, int w, int h) {
        ctx.fill(x, y, x + w, y + h, BG);
        ctx.fill(x, y, x + w, y + 1, Theme.secondary());
    }

    private static void watermark(DrawContext ctx, TextRenderer tr) {
        String a = "Belka Jay";
        String b = " visual";
        int w = tr.getWidth(a) + tr.getWidth(b) + 14;
        box(ctx, 6, 6, w, 16);
        ctx.drawText(tr, a, 13, 10, Theme.primary(), true);
        ctx.drawText(tr, b, 13 + tr.getWidth(a), 10, Theme.secondary(), true);
    }

    private static void potions(DrawContext ctx, MinecraftClient mc, TextRenderer tr) {
        int y = 28;
        for (StatusEffectInstance e : mc.player.getStatusEffects()) {
            if (ModuleManager.FULLBRIGHT.isEnabled() && e.getEffectType().matches(StatusEffects.NIGHT_VISION)) continue;
            String name = e.getEffectType().value().getName().getString() + " " + (e.getAmplifier() + 1);
            int secs = e.getDuration() / 20;
            String time = e.isInfinite() ? "inf" : String.format("%d:%02d", secs / 60, secs % 60);
            int w = tr.getWidth(name) + tr.getWidth(time) + 20;
            box(ctx, 6, y, w, 14);
            ctx.drawText(tr, name, 11, y + 3, Theme.primary(), true);
            ctx.drawText(tr, time, 11 + tr.getWidth(name) + 8, y + 3, Theme.secondary(), true);
            y += 16;
        }
    }

    private static void info(DrawContext ctx, MinecraftClient mc, TextRenderer tr) {
        int ping = 0;
        if (mc.getNetworkHandler() != null) {
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (e != null) ping = e.getLatency();
        }
        String line = "FPS " + mc.getCurrentFps()
                + "  |  Ping " + ping + "ms"
                + "  |  CPS " + Effects.cps()
                + "  |  " + String.format("%.1f", Effects.speed) + " b/s"
                + "  |  XYZ " + mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ();
        int w = tr.getWidth(line) + 12;
        int y = ctx.getScaledWindowHeight() - 22;
        box(ctx, 6, y, w, 16);
        ctx.drawText(tr, line, 12, y + 4, Theme.primary(), true);
    }

    private static void arrayList(DrawContext ctx, TextRenderer tr) {
        List<Feature> active = new ArrayList<>();
        for (Feature f : ModuleManager.ALL) if (f.isEnabled() && f.isListed()) active.add(f);
        active.sort(Comparator.comparingInt((Feature f) -> tr.getWidth(text(f))).reversed());

        int screenW = ctx.getScaledWindowWidth();
        int y = 6;
        for (int i = 0; i < active.size(); i++) {
            Feature f = active.get(i);
            int w = tr.getWidth(text(f)) + 8;
            int x = screenW - w - 4;
            int col = i % 2 == 0 ? Theme.primary() : Theme.secondary();
            ctx.fill(x, y, x + w, y + 12, BG);
            ctx.fill(x + w, y, x + w + 2, y + 12, col);
            ctx.drawText(tr, f.getName(), x + 4, y + 2, col, true);
            if (f.hasModes()) {
                ctx.drawText(tr, " " + f.getMode(), x + 4 + tr.getWidth(f.getName()), y + 2, 0xFF7C7B8C, true);
            }
            y += 12;
        }
    }

    private static String text(Feature f) {
        return f.hasModes() ? f.getName() + " " + f.getMode() : f.getName();
    }

    private static void targetHud(DrawContext ctx, MinecraftClient mc, TextRenderer tr) {
        Entity t = mc.targetedEntity;
        if (!(t instanceof LivingEntity le)) return;
        String name = le.getName().getString();
        float hp = le.getHealth();
        float max = Math.max(1f, le.getMaxHealth());
        int w = Math.max(110, tr.getWidth(name) + 20);
        int h = 34;
        int x = ctx.getScaledWindowWidth() / 2 + 20;
        int y = ctx.getScaledWindowHeight() / 2 + 20;
        box(ctx, x, y, w, h);
        ctx.drawText(tr, name, x + 8, y + 7, Theme.primary(), true);
        ctx.drawText(tr, String.format("%.1f / %.1f", hp, max), x + 8, y + 18, Theme.secondary(), false);
        int barW = w - 16;
        int filled = (int) (barW * Math.min(1f, hp / max));
        ctx.fill(x + 8, y + h - 7, x + 8 + barW, y + h - 4, 0xFF2A2A33);
        ctx.fill(x + 8, y + h - 7, x + 8 + filled, y + h - 4, Theme.primary());
    }

    private static void keystrokes(DrawContext ctx, MinecraftClient mc, TextRenderer tr) {
        int s = 20, g = 2;
        int x0 = 8;
        int y0 = ctx.getScaledWindowHeight() / 2 - 40;
        key(ctx, tr, "W", x0 + s + g, y0, s, s, mc.options.forwardKey.isPressed());
        key(ctx, tr, "A", x0, y0 + s + g, s, s, mc.options.leftKey.isPressed());
        key(ctx, tr, "S", x0 + s + g, y0 + s + g, s, s, mc.options.backKey.isPressed());
        key(ctx, tr, "D", x0 + 2 * (s + g), y0 + s + g, s, s, mc.options.rightKey.isPressed());
        int y2 = y0 + 2 * (s + g);
        key(ctx, tr, "LMB", x0, y2, 31, s, mc.options.attackKey.isPressed());
        key(ctx, tr, "RMB", x0 + 33, y2, 31, s, mc.options.useKey.isPressed());
        key(ctx, tr, "", x0, y2 + s + g, 64, 8, mc.options.jumpKey.isPressed());
    }

    private static void key(DrawContext ctx, TextRenderer tr, String label, int x, int y, int w, int h, boolean down) {
        ctx.fill(x, y, x + w, y + h, down ? Theme.primary() : BG);
        if (!label.isEmpty()) {
            ctx.drawText(tr, label, x + (w - tr.getWidth(label)) / 2, y + (h - 8) / 2 + 1,
                    down ? 0xFF050508 : Theme.primary(), false);
        }
    }

    private static void items(DrawContext ctx, MinecraftClient mc, TextRenderer tr) {
        int x = ctx.getScaledWindowWidth() - 24;
        int y = ctx.getScaledWindowHeight() - 22;
        if (ModuleManager.TOTEMS.isEnabled()) {
            int count = 0;
            var inv = mc.player.getInventory();
            for (int i = 0; i < inv.size(); i++) {
                ItemStack st = inv.getStack(i);
                if (st.isOf(Items.TOTEM_OF_UNDYING)) count += st.getCount();
            }
            ctx.drawItem(new ItemStack(Items.TOTEM_OF_UNDYING), x, y);
            String c = String.valueOf(count);
            ctx.drawText(tr, c, x + 16 - tr.getWidth(c), y + 9, count == 0 ? 0xFFFF6B6B : Theme.primary(), true);
            x -= 20;
        }
        if (ModuleManager.ARMOR_HUD.isEnabled()) {
            EquipmentSlot[] slots = {EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.CHEST, EquipmentSlot.HEAD};
            for (EquipmentSlot slot : slots) {
                ItemStack st = mc.player.getEquippedStack(slot);
                if (!st.isEmpty()) {
                    ctx.drawItem(st, x, y);
                    ctx.drawStackOverlay(tr, st, x, y);
                }
                x -= 18;
            }
        }
    }

    private static void crosshair(DrawContext ctx) {
        int cx = ctx.getScaledWindowWidth() / 2;
        int cy = ctx.getScaledWindowHeight() / 2;
        int c = Theme.primary();
        switch (ModuleManager.CROSSHAIR.getMode()) {
            case "Dot" -> ctx.fill(cx - 1, cy - 1, cx + 1, cy + 1, c);
            case "Ring" -> {
                for (int i = 0; i < 20; i++) {
                    double a = Math.PI * 2 * i / 20;
                    int px = cx + (int) Math.round(Math.cos(a) * 5);
                    int py = cy + (int) Math.round(Math.sin(a) * 5);
                    ctx.fill(px, py, px + 1, py + 1, c);
                }
                ctx.fill(cx, cy, cx + 1, cy + 1, c);
            }
            default -> {
                ctx.fill(cx - 7, cy, cx - 3, cy + 1, c);
                ctx.fill(cx + 4, cy, cx + 8, cy + 1, c);
                ctx.fill(cx, cy - 7, cx + 1, cy - 3, c);
                ctx.fill(cx, cy + 4, cx + 1, cy + 8, c);
            }
        }
    }
}

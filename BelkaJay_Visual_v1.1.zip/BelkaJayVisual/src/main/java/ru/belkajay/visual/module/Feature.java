package ru.belkajay.visual.module;

public class Feature {
    private final String name;
    private boolean enabled;
    private String[] modes = new String[0];
    private int modeIndex = 0;
    private boolean listed = true;
    private boolean modeOnly = false;

    public Feature(String name, boolean enabledByDefault) {
        this.name = name;
        this.enabled = enabledByDefault;
    }

    public Feature modes(String... modes) { this.modes = modes; return this; }
    public Feature unlisted() { this.listed = false; return this; }
    public Feature modeOnly() { this.modeOnly = true; this.listed = false; this.enabled = true; return this; }

    public String getName() { return name; }
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean v) { enabled = v; }
    public void toggle() { enabled = !enabled; }

    public boolean isListed() { return listed; }
    public boolean isModeOnly() { return modeOnly; }
    public boolean hasModes() { return modes.length > 0; }
    public String getMode() { return modes.length == 0 ? "" : modes[modeIndex]; }
    public int getModeIndex() { return modeIndex; }

    public void setModeIndex(int i) {
        if (modes.length == 0) return;
        modeIndex = Math.floorMod(i, modes.length);
    }

    public void cycleMode() { setModeIndex(modeIndex + 1); }
}

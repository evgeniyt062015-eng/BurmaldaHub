package ru.belkajay.visual.module;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class ModuleManager {
    public static final List<Feature> ALL = new ArrayList<>();

    public static final String[] PARTICLES =
            {"Crit", "Heart", "Flame", "Snow", "Spark", "Cloud", "Star", "Happy"};

    // ---------- Theme ----------
    public static final Feature THEME = add(new Feature("Theme", true)
            .modes("Mono", "Ice", "Violet", "Mint", "Rose").modeOnly());

    // ---------- HUD ----------
    public static final Feature WATERMARK   = add(new Feature("Watermark", true));
    public static final Feature ARRAY_LIST  = add(new Feature("ArrayList", true).unlisted());
    public static final Feature INFO        = add(new Feature("Info", true));
    public static final Feature TARGET_HUD  = add(new Feature("TargetHUD", true));
    public static final Feature KEYSTROKES  = add(new Feature("Keystrokes", false));
    public static final Feature POTION_HUD  = add(new Feature("PotionHUD", true));
    public static final Feature ARMOR_HUD   = add(new Feature("ArmorHUD", true));
    public static final Feature TOTEMS      = add(new Feature("TotemCounter", false));
    public static final Feature CROSSHAIR   = add(new Feature("Crosshair", false).modes("Cross", "Dot", "Ring"));

    // ---------- World / effects ----------
    public static final Feature HIT_PARTICLES = add(new Feature("HitParticles", true).modes(PARTICLES));
    public static final Feature JUMP_CIRCLE   = add(new Feature("JumpCircle", true).modes(rotate(PARTICLES, 6)));
    public static final Feature TRAIL         = add(new Feature("Trail", false).modes(rotate(PARTICLES, 5)));
    public static final Feature TARGET_ESP    = add(new Feature("TargetESP", true).modes(rotate(PARTICLES, 4)));
    public static final Feature TIME_CHANGER  = add(new Feature("TimeChanger", false).modes("Day", "Noon", "Sunset", "Night", "Midnight"));
    public static final Feature FULLBRIGHT    = add(new Feature("Fullbright", false));
    public static final Feature NO_HURT_CAM   = add(new Feature("NoHurtCam", false));
    public static final Feature ZOOM          = add(new Feature("Zoom", true).modes("x2", "x3", "x4", "x6"));

    private static Feature add(Feature f) {
        ALL.add(f);
        return f;
    }

    private static String[] rotate(String[] src, int shift) {
        String[] out = new String[src.length];
        for (int i = 0; i < src.length; i++) out[i] = src[(i + shift) % src.length];
        return out;
    }

    // ---------- Config ----------
    private static Path configPath() {
        return FabricLoader.getInstance().getConfigDir().resolve("belkajay-visual.properties");
    }

    public static void init() {
        Path p = configPath();
        if (!Files.exists(p)) return;
        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(p)) {
            props.load(in);
        } catch (IOException ignored) {
            return;
        }
        for (Feature f : ALL) {
            String en = props.getProperty(f.getName() + ".enabled");
            if (en != null && !f.isModeOnly()) f.setEnabled(Boolean.parseBoolean(en));
            String mode = props.getProperty(f.getName() + ".mode");
            if (mode != null) {
                try { f.setModeIndex(Integer.parseInt(mode)); } catch (NumberFormatException ignored) {}
            }
        }
    }

    public static void save() {
        Properties props = new Properties();
        for (Feature f : ALL) {
            props.setProperty(f.getName() + ".enabled", Boolean.toString(f.isEnabled()));
            if (f.hasModes()) props.setProperty(f.getName() + ".mode", Integer.toString(f.getModeIndex()));
        }
        try (OutputStream out = Files.newOutputStream(configPath())) {
            props.store(out, "Belka Jay Visual");
        } catch (IOException ignored) {
        }
    }
}

# Belka Jay Visual (Fabric, Minecraft 1.21.4)

Клиентский визуальный мод: HUD и косметика. Ничего не отправляет на сервер, всё видно только тебе.

## Функции

**HUD**
- Watermark: плашка «Belka Jay visual»
- ArrayList: список включённых функций справа, с режимами
- Info: FPS, пинг, CPS, скорость (блоки/сек), координаты
- TargetHUD: имя и здоровье цели под прицелом
- Keystrokes: WASD, LMB, RMB, пробел
- PotionHUD: активные эффекты с таймером
- ArmorHUD: броня с прочностью
- TotemCounter: сколько тотемов в инвентаре
- Crosshair: свой прицел (Cross / Dot / Ring), ванильный скрывается
- Theme: Mono (как на аватарке), Ice, Violet, Mint, Rose

**Эффекты и мир**
- HitParticles: частицы при ударе (8 видов)
- JumpCircle: расходящееся кольцо частиц при прыжке
- Trail: след из частиц при беге
- TargetESP: вращающееся кольцо частиц вокруг цели под прицелом (без просвечивания сквозь стены)
- TimeChanger: Day / Noon / Sunset / Night / Midnight (только на твоём клиенте)
- Fullbright: яркость через клиентское ночное зрение
- NoHurtCam: без тряски камеры при уроне
- Zoom: удерживай C (x2 / x3 / x4 / x6), плавный

## Управление
- **Right Shift**: меню. Кнопка с названием включает или выключает функцию, кнопка `>` рядом меняет режим.
- **C**: зум (клавиши меняются в настройках управления, категория «Belka Jay Visual»).
- Настройки сохраняются в `config/belkajay-visual.properties` при закрытии меню.

## Сборка
Нужны JDK 21 и интернет.
1. Открой папку в IntelliJ IDEA (Gradle-проект) или выполни `gradle build`.
2. Jar будет в `build/libs/belkajay-visual-1.1.0.jar`. Клади его в `mods/` вместе с Fabric Loader и Fabric API для 1.21.4.

Версии зависимостей лежат в `gradle.properties` (актуальные: https://fabricmc.net/develop).
Если при сборке или запуске есть ошибка, пришли текст ошибки: подправлю.

Иконка мода: `src/main/resources/assets/belkajay/icon.png` (твоя аватарка).
Примечание: некоторые сервера запрещают Fullbright и TimeChanger, проверяй правила.
